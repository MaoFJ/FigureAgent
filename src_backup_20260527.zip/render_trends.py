"""
趋势对比方案生成器 —— 输出 4 种 GIF 供对比选择

用法: python src/render_trends.py
输出: output/trends/S{1-4}_*.gif
"""

import sys
from pathlib import Path
import numpy as np
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parent))

import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman", "SimSun", "DejaVu Serif"]
plt.rcParams["text.color"] = "black"
plt.rcParams["axes.unicode_minus"] = False
import warnings; warnings.filterwarnings("ignore")

from config import YEARS, SCENARIO_SHORT, INVENTORY_CSV
from core import DataLoader, load_forest_average, load_and_average

# ── 参数 ──────────────────────────────────────────────
VARIABLE  = "NEE"
FOREST    = "Forest"
SCENARIO  = "ssp585"
BASELINE  = list(range(2015, 2021))
OUT_DIR   = Path(r"d:\Programs\FigureAgent\output\trends")
FIG_W, FIG_H, DPI = 12, 7, 150

# ── 数据加载 ──────────────────────────────────────────
def load_all():
    loader = DataLoader(INVENTORY_CSV)
    lon, lat = loader.lon_lat_grid()
    stack = []
    for yr in tqdm(YEARS, desc="加载"):
        d = load_forest_average(loader, SCENARIO, VARIABLE, yr) if FOREST == "Forest" \
            else load_and_average(loader, SCENARIO, FOREST, VARIABLE, yr)
        stack.append(d)
    stack = np.array(stack)
    bi = [YEARS.index(y) for y in BASELINE]
    base = np.nanmean(stack[bi], axis=0)
    lspan = lon.max() - lon.min(); lts = lat.max() - lat.min()
    ext = [lon.min() - lspan * 0.06, lon.max() + lspan * 0.06,
           lat.min() - lts * 0.06, lat.max() + lts * 0.06]
    return lon, lat, stack, base, ext

# ── 渲染引擎 ──────────────────────────────────────────
def render(frames, label, cmap_name, vmin, vmax, tag, ext, lon, lat):
    import imageio.v2 as iio
    fd = OUT_DIR / "_f" / tag; fd.mkdir(parents=True, exist_ok=True)
    cm = plt.cm.get_cmap(cmap_name).copy(); cm.set_bad("white", alpha=0)
    norm = plt.Normalize(vmin, vmax)

    for i, data in enumerate(tqdm(frames, desc=tag)):
        fp = fd / f"frm_{YEARS[i]:04d}.png"
        if fp.exists(): continue
        fig = plt.figure(figsize=(FIG_W, FIG_H), dpi=DPI, facecolor="white")
        ax = plt.axes(projection=ccrs.PlateCarree()); ax.set_facecolor("white")
        ax.set_extent(ext, crs=ccrs.PlateCarree())
        ax.add_feature(cfeature.LAND, facecolor="white", zorder=0)
        ax.add_feature(cfeature.OCEAN, facecolor="white", zorder=0)
        ax.add_feature(cfeature.COASTLINE, lw=0.6, edgecolor="#888", zorder=2)
        ax.add_feature(cfeature.BORDERS, lw=0.4, edgecolor="#aaa", zorder=2)
        gl = ax.gridlines(draw_labels=True, lw=0.3, color="#ccc", alpha=0.35, ls="--",
                          xlocs=_dt(lon.min(), lon.max()), ylocs=_dt(lat.min(), lat.max()))
        gl.top_labels = gl.right_labels = gl.left_labels = gl.bottom_labels = True
        gl.xlabel_style = {"size": 7, "color": "black"}
        gl.ylabel_style = {"size": 7, "color": "black"}
        dm = np.where(np.abs(data) < 0.001, np.nan, data)
        ax.pcolormesh(lon, lat, dm, cmap=cm, norm=norm, transform=ccrs.PlateCarree(),
                      rasterized=True, shading="auto")
        # 色带
        bb = ax.get_position()
        ca = fig.add_axes([bb.x1 - 0.76, bb.y0 + bb.height * 0.15, 0.015, bb.height * 0.55])
        cb = plt.colorbar(plt.cm.ScalarMappable(norm, cm), cax=ca, orientation="vertical")
        cb.outline.set_visible(False); cb.ax.tick_params(labelsize=7, length=2, pad=2)
        ca.text(0, 1.04, label, transform=ca.transAxes, ha="left", va="bottom",
                fontsize=7.5, fontweight="bold", color="#333")
        # 标题
        ax.text(0.02, 0.96, f"{SCENARIO_SHORT.get(SCENARIO, SCENARIO)}-{VARIABLE}-{YEARS[i]}",
                transform=ax.transAxes, ha="left", va="top", fontsize=14, fontweight="bold",
                color="#222", bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#ccc", alpha=0.85))
        fig.savefig(fp, dpi=DPI, bbox_inches="tight", facecolor="white", edgecolor="none")
        plt.close(fig)
    imgs = [iio.imread(str(f)) for f in sorted(fd.glob("frm_*.png"))]
    gp = OUT_DIR / f"{tag}.gif"; iio.mimsave(gp, imgs, duration=0.5, loop=0)
    print(f"  [OK] {gp}")

def _dt(vmin, vmax):
    span = vmax - vmin; step = 1 if span <= 12 else 5 if span <= 40 else 10
    s = np.ceil(vmin / step) * step; e = np.floor(vmax / step) * step
    return list(np.arange(s, e + step * 0.5, step))

# ── 4 方案 ────────────────────────────────────────────
def main():
    lon, lat, stack, base, ext = load_all()

    # S1: 绝对地图 (对照)
    print("\nS1 绝对地图")
    v1 = [np.where(np.abs(d) < 0.001, np.nan, d) for d in stack]
    render(v1, "NEE (gC/m2/yr)", "YlOrBr", 0, 2000, "S1_absolute", ext, lon, lat)

    # S2: 距平 (每年 - 基线 2015-2020)
    print("\nS2 距平地图")
    anom = [stack[i] - base for i in range(len(YEARS))]
    aa = np.concatenate([a[~np.isnan(a)] for a in anom])
    mx = max(abs(np.percentile(aa, 2)), abs(np.percentile(aa, 98)))
    mx = np.ceil(mx / 100) * 100 or 500
    v2 = [np.where(np.abs(a) < 0.01, np.nan, a) for a in anom]
    render(v2, "ΔNEE (gC/m2/yr)", "RdBu_r", -mx, mx, "S2_anomaly", ext, lon, lat)

    # S3: 累积变化 (每年 - 2015)
    print("\nS3 累积变化")
    cum = [stack[i] - stack[0] for i in range(len(YEARS))]
    ca = np.concatenate([c[~np.isnan(c)] for c in cum])
    cx = max(abs(np.percentile(ca, 2)), abs(np.percentile(ca, 98)))
    cx = np.ceil(cx / 100) * 100 or 500
    v3 = [np.where(np.abs(c) < 0.01, np.nan, c) for c in cum]
    render(v3, "ΔNEE vs 2015 (gC/m2/yr)", "RdBu_r", -cx, cx, "S3_cumulative", ext, lon, lat)

    # S4: 5年滑动距平
    print("\nS4 5年滑动距平")
    w = 5; h = w // 2
    smooth = np.array([np.nanmean(stack[max(0,i-h):min(len(YEARS),i+h+1)], axis=0) for i in range(len(YEARS))])
    sa = [smooth[i] - base for i in range(len(YEARS))]
    ssa = np.concatenate([s[~np.isnan(s)] for s in sa])
    sx = max(abs(np.percentile(ssa, 2)), abs(np.percentile(ssa, 98)))
    sx = np.ceil(sx / 100) * 100 or 500
    v4 = [np.where(np.abs(s) < 0.01, np.nan, s) for s in sa]
    render(v4, "ΔNEE 5yr-smooth (gC/m2/yr)", "RdBu_r", -sx, sx, "S4_smoothed", ext, lon, lat)

    print(f"\n完成 → {OUT_DIR}")
    print("  S1_absolute.gif   - 绝对地图 (对照)")
    print("  S2_anomaly.gif    - 距平 (每年 - 2015-2020基线)")
    print("  S3_cumulative.gif - 累积变化 (每年 - 2015)")
    print("  S4_smoothed.gif   - 5年滑动平均距平")

if __name__ == "__main__":
    main()